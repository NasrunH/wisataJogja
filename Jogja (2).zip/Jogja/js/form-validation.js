document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('registrationForm');
    const steps = Array.from(document.querySelectorAll('.form-step'));
    const progressSteps = Array.from(document.querySelectorAll('.progress-bar .step'));
    const nextButtons = document.querySelectorAll('.btn-next');
    const prevButtons = document.querySelectorAll('.btn-prev');
    const submitButton = document.querySelector('.btn-submit');
    const passwordInput = document.getElementById('password');
    const strengthItems = document.querySelectorAll('.strength-item');
    let currentStep = 0;

    function showStep(stepIndex) {
        steps.forEach((step, index) => {
            step.classList.toggle('active', index === stepIndex);
            progressSteps[index].classList.toggle('active', index <= stepIndex);
        });
    }

    function validateStep(stepIndex) {
        const currentStepElement = steps[stepIndex];
        const inputs = currentStepElement.querySelectorAll('input, select');
        let isValid = true;

        inputs.forEach(input => {
            if (input.hasAttribute('required') && !input.value.trim()) {
                showError(input, 'Bidang ini wajib diisi');
                isValid = false;
            } else if (input.type === 'email' && !isValidEmail(input.value)) {
                showError(input, 'Email tidak valid');
                isValid = false;
            } else if (input.type === 'tel' && !isValidPhone(input.value)) {
                showError(input, 'Nomor telepon tidak valid');
                isValid = false;
            } else if (input.id === 'password' && !isValidPassword(input.value)) {
                showError(input, 'Password tidak memenuhi kriteria');
                isValid = false;
            } else if (input.id === 'confirm-password' && input.value !== document.getElementById('password').value) {
                showError(input, 'Password tidak cocok');
                isValid = false;
            } else {
                clearError(input);
            }
        });

        return isValid;
    }

    function showError(input, message) {
        const errorElement = input.nextElementSibling;
        errorElement.textContent = message;
        input.classList.add('error');
    }

    function clearError(input) {
        const errorElement = input.nextElementSibling;
        errorElement.textContent = '';
        input.classList.remove('error');
    }

    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function isValidPhone(phone) {
        const re = /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/;
        return re.test(phone);
    }

    function isValidPassword(password) {
        const minLength = password.length >= 8;
        const hasUpperLower = /(?=.*[a-z])(?=.*[A-Z])/.test(password);
        const hasNumber = /\d/.test(password);
        const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

        updatePasswordStrength(minLength, hasUpperLower, hasNumber, hasSpecialChar);

        return minLength && hasUpperLower && hasNumber && hasSpecialChar;
    }

    function updatePasswordStrength(minLength, hasUpperLower, hasNumber, hasSpecialChar) {
        const criteria = [minLength, hasUpperLower, hasNumber, hasSpecialChar];
        strengthItems.forEach((item, index) => {
            const icon = item.querySelector('i');
            if (criteria[index]) {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-check');
            } else {
                icon.classList.remove('fa-check');
                icon.classList.add('fa-times');
            }
        });
    }

    function updateSummary() {
        const summary = document.getElementById('summary');
        const formData = new FormData(form);
        let summaryHTML = '<h4>Ringkasan Pendaftaran:</h4>';

        for (let [key, value] of formData.entries()) {
            if (key === 'setuju' || key === 'password' || key === 'confirm-password') continue;
            summaryHTML += `<p><strong>${key}:</strong> ${value}</p>`;
        }

        summary.innerHTML = summaryHTML;
    }

    nextButtons.forEach(button => {
        button.addEventListener('click', () => {
            if (validateStep(currentStep)) {
                currentStep++;
                showStep(currentStep);
                if (currentStep === steps.length - 1) {
                    updateSummary();
                }
            }
        });
    });

    prevButtons.forEach(button => {
        button.addEventListener('click', () => {
            currentStep--;
            showStep(currentStep);
        });
    });

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        if (validateStep(currentStep)) {
            alert('Pendaftaran akun berhasil! Silakan login dengan akun baru Anda.');
            form.reset();
            currentStep = 0;
            showStep(currentStep);
        }
    });

    passwordInput.addEventListener('input', function() {
        isValidPassword(this.value);
    });

    showStep(currentStep);
});

