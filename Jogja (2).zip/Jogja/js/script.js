const modal = document.getElementById("loginModal");
const loginButton = document.getElementById("loginButton");
const closeButton = document.querySelector(".close");

if (loginButton && modal && closeButton) {
    loginButton.addEventListener('click', function(e) {
        e.preventDefault();
        modal.style.display = "block";
    });

    closeButton.addEventListener('click', function() {
        modal.style.display = "none";
    });

    window.addEventListener('click', function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    });

    // Login form submission (for demonstration purposes)
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;
            console.log("Login attempt:", username, password);
            alert("Login functionality would be implemented here.");
            modal.style.display = "none";
        });
    }
}


const currentLocation = window.location.pathname;
const menuItems = document.querySelectorAll('nav ul li a');

menuItems.forEach(item => {
    // Memeriksa apakah href dari item menu sama dengan URL saat ini
    if (item.getAttribute('href') === currentLocation) {
          item.classList.add('active'); // Menambahkan kelas active
       }
 });